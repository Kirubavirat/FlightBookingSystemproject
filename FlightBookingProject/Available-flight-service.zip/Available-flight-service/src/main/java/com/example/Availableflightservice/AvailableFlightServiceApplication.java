package com.example.Availableflightservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AvailableFlightServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(AvailableFlightServiceApplication.class, args);
	}

}
