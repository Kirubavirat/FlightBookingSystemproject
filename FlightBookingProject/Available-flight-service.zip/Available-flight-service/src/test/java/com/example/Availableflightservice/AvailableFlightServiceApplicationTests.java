package com.example.Availableflightservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AvailableFlightServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
